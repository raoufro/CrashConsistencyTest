#define WRITE
#include "iopat.c"
